import 'package:flutter/material.dart';

void main() {
  runApp(const MessagesBoardApp());
}

class MessagesBoardApp extends StatelessWidget {
  const MessagesBoardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Messages',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2B59C3)),
        useMaterial3: true,
      ),
      home: const MessagesBoardScreen(),
    );
  }
}

class MessagesBoardScreen extends StatelessWidget {
  const MessagesBoardScreen({super.key});

  static const Color _bgSlate = Color(0xFFDDE3EC);
  static const Color _panelWhite = Color(0xFFFDFEFE);
  static const Color _outlineTint = Color(0xFFB8C4D4);
  static const Color _accentRoyal = Color(0xFF2B59C3);
  static const Color _textSlate = Color(0xFF1B2432);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgSlate,
      appBar: AppBar(
        backgroundColor: _bgSlate,
        surfaceTintColor: Colors.transparent,
        leading: const Icon(Icons.mail_outline, size: 28, color: _textSlate),
        title: const Text(
          'Messages',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            color: _textSlate,
          ),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: const [
              FieldPanel(
                fieldTitle: 'From:',
                panelHeight: 48,
                cornerRadius: 14,
                fillColor: _panelWhite,
                borderColor: _outlineTint,
                labelColor: _textSlate,
              ),
              SizedBox(height: 12),
              FieldPanel(
                fieldTitle: 'To:',
                panelHeight: 48,
                cornerRadius: 14,
                fillColor: _panelWhite,
                borderColor: _outlineTint,
                labelColor: _textSlate,
              ),
              SizedBox(height: 14),
              FieldPanel(
                fieldTitle: 'Compose Message:',
                panelHeight: 185,
                cornerRadius: 16,
                fillColor: _panelWhite,
                borderColor: _outlineTint,
                labelColor: _textSlate,
              ),
              SizedBox(height: 22),
              SubmitBar(label: 'SEND', buttonColor: _accentRoyal),
              Spacer(),
              FooterShortcut(tint: _textSlate),
            ],
          ),
        ),
      ),
    );
  }
}

class FieldPanel extends StatelessWidget {
  const FieldPanel({
    super.key,
    required this.fieldTitle,
    required this.panelHeight,
    required this.cornerRadius,
    required this.fillColor,
    required this.borderColor,
    required this.labelColor,
  });

  final String fieldTitle;
  final double panelHeight;
  final double cornerRadius;
  final Color fillColor;
  final Color borderColor;
  final Color labelColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: panelHeight,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: fillColor,
        borderRadius: BorderRadius.circular(cornerRadius),
        border: Border.all(color: borderColor),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            fieldTitle,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: labelColor,
            ),
          ),
        ],
      ),
    );
  }
}

class SubmitBar extends StatelessWidget {
  const SubmitBar({super.key, required this.label, required this.buttonColor});

  final String label;
  final Color buttonColor;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 220,
        height: 44,
        decoration: BoxDecoration(
          color: buttonColor,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.send_rounded, size: 18, color: Colors.white),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FooterShortcut extends StatelessWidget {
  const FooterShortcut({super.key, required this.tint});

  final Color tint;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [Icon(Icons.home_outlined, size: 32, color: tint)],
    );
  }
}
